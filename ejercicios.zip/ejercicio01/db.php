<?php

define('DB_HOST', 'sql303.infinityfree.com');
define('DB_USER', 'if0_41883543');   
define('DB_PASS', 'gcchristR17');  
define('DB_NAME', 'if0_41883543_pwa_tareas');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn_with_db = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $dsn_no_db   = "mysql:host=" . DB_HOST . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn_with_db, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        // La base de datos no existe: crearla y estructurarla
        try {
            $tmp = new PDO($dsn_no_db, DB_USER, DB_PASS, $options);
            $tmp->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $tmp->exec("USE `" . DB_NAME . "`");

            $tmp->exec("CREATE TABLE IF NOT EXISTS roles (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(50) NOT NULL UNIQUE
            )");
            $tmp->exec("CREATE TABLE IF NOT EXISTS usuarios (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(80) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                rol_id INT NOT NULL,
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (rol_id) REFERENCES roles(id)
            )");
            $tmp->exec("CREATE TABLE IF NOT EXISTS tareas (
                id INT AUTO_INCREMENT PRIMARY KEY,
                titulo VARCHAR(200) NOT NULL,
                descripcion TEXT,
                completada TINYINT(1) DEFAULT 0,
                prioridad ENUM('baja','media','alta') DEFAULT 'media',
                usuario_id INT NOT NULL,
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
            )");

            $tmp->exec("INSERT IGNORE INTO roles (id, nombre) VALUES (1, 'admin'), (2, 'usuario')");
            $stmt = $tmp->prepare("INSERT IGNORE INTO usuarios (id, username, password, rol_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([1, 'admin',    password_hash('admin123', PASSWORD_BCRYPT), 1]);
            $stmt->execute([2, 'usuario1', password_hash('user123',  PASSWORD_BCRYPT), 2]);

            $pdo = new PDO($dsn_with_db, DB_USER, DB_PASS, $options);
        } catch (PDOException $e2) {
            die("<p style='font-family:monospace;color:red;padding:20px;'>
                <strong>Error de conexión a la base de datos.</strong><br>
                Verifica las credenciales en <code>db.php</code>.<br>
                Detalle: " . htmlspecialchars($e2->getMessage()) . "
            </p>");
        }
    }
    return $pdo;
}
