<?php
// ejercicio01/index.php — Lista de Tareas con Roles
session_start();
require_once __DIR__ . '/db.php';
$db = getDB();

$error = '';
$msg   = '';

// 1. Login
if (isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $db->prepare("SELECT u.*, r.nombre AS rol FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE u.username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['uid']      = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['rol']      = $user['rol'];
        header("Location: index.php"); exit;
    } else {
        $error = "Credenciales incorrectas.";
    }
}

// 2. Logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy(); header("Location: index.php"); exit;
}

// Acciones protegidas
if (!empty($_SESSION['uid'])) {
    $uid = (int)$_SESSION['uid'];
    $rol = $_SESSION['rol'];

    // 3. Crear Tarea
    if (isset($_POST['action']) && $_POST['action'] === 'create_task') {
        $titulo      = trim($_POST['titulo'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $prioridad   = in_array($_POST['prioridad'] ?? '', ['baja','media','alta']) ? $_POST['prioridad'] : 'media';
        $asignado    = ($rol === 'admin' && !empty($_POST['usuario_id'])) ? (int)$_POST['usuario_id'] : $uid;
        if ($titulo) {
            $db->prepare("INSERT INTO tareas (titulo, descripcion, prioridad, usuario_id) VALUES (?, ?, ?, ?)")
               ->execute([$titulo, $descripcion, $prioridad, $asignado]);
            $msg = "Tarea creada con éxito.";
        } else {
            $error = "El título es obligatorio.";
        }
    }

    // 4. Toggle completado
    if (isset($_GET['action']) && $_GET['action'] === 'toggle') {
        $tid  = (int)$_GET['id'];
        $stmt = $db->prepare("SELECT * FROM tareas WHERE id = ?");
        $stmt->execute([$tid]);
        $tarea = $stmt->fetch();
        if ($tarea && ($rol === 'admin' || $tarea['usuario_id'] == $uid)) {
            $db->prepare("UPDATE tareas SET completada = ? WHERE id = ?")->execute([$tarea['completada'] ? 0 : 1, $tid]);
        }
        header("Location: index.php"); exit;
    }

    // 5. Eliminar Tarea
    if (isset($_GET['action']) && $_GET['action'] === 'delete_task') {
        $tid  = (int)$_GET['id'];
        $stmt = $db->prepare("SELECT * FROM tareas WHERE id = ?");
        $stmt->execute([$tid]);
        $tarea = $stmt->fetch();
        if ($tarea && ($rol === 'admin' || $tarea['usuario_id'] == $uid)) {
            $db->prepare("DELETE FROM tareas WHERE id = ?")->execute([$tid]);
            $msg = "Tarea eliminada.";
        }
    }

    // 6. Crear Usuario (Solo Admin)
    if (isset($_POST['action']) && $_POST['action'] === 'create_user' && $rol === 'admin') {
        $new_user   = trim($_POST['new_username'] ?? '');
        $new_pass   = $_POST['new_password'] ?? '';
        $new_rol_id = (int)($_POST['new_rol'] ?? 2);
        if ($new_user && $new_pass) {
            try {
                $db->prepare("INSERT INTO usuarios (username, password, rol_id) VALUES (?, ?, ?)")
                   ->execute([$new_user, password_hash($new_pass, PASSWORD_BCRYPT), $new_rol_id]);
                $msg = "Usuario '{$new_user}' creado correctamente.";
            } catch (PDOException $e) {
                $error = "El nombre de usuario ya existe.";
            }
        } else {
            $error = "Completa todos los campos del nuevo usuario.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TaskFlow — Gestión de Tareas</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet" />
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --bg: #06060a; --surface: #0e0e16; --border: #1a1a2e;
            --accent: #6d28d9; --accent2: #a855f7;
            --text: #f1f5f9; --muted: #64748b; --card: #0d0d18;
            --danger: #ef4444; --success: #22c55e;
        }
        body { font-family: 'Outfit', sans-serif; background: var(--bg); color: var(--text); min-height: 100vh; padding: 2rem 1rem; }
        body::before {
            content: ''; position: fixed; inset: 0;
            background-image: linear-gradient(rgba(109,40,217,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(109,40,217,0.03) 1px, transparent 1px);
            background-size: 50px 50px; pointer-events: none;
        }

        .wrap { max-width: 780px; margin: 0 auto; position: relative; z-index: 1; }

        /* Topbar */
        .topbar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 2.5rem; gap: 1rem; flex-wrap: wrap; }
        .topbar a { font-family: 'DM Mono', monospace; font-size: 0.78rem; color: var(--muted); text-decoration: none; }
        .topbar a:hover { color: var(--text); }
        .user-pill {
            display: flex; align-items: center; gap: 8px;
            background: var(--card); border: 1px solid var(--border); border-radius: 99px;
            padding: 6px 14px; font-size: 0.82rem;
        }
        .role-badge {
            font-family: 'DM Mono', monospace; font-size: 0.65rem;
            background: var(--accent); color: white; padding: 2px 8px; border-radius: 99px;
        }
        .role-badge.usuario { background: #0e7490; }

        /* Page title */
        .page-title { margin-bottom: 2rem; }
        .page-title h1 { font-size: 1.9rem; font-weight: 700; letter-spacing: -0.02em; }
        .page-title p  { color: var(--muted); font-size: 0.9rem; margin-top: 4px; }

        /* Alerts */
        .alert { padding: 12px 16px; border-radius: 10px; font-size: 0.88rem; margin-bottom: 1.5rem; }
        .alert-error   { background: rgba(239,68,68,0.1);  border: 1px solid rgba(239,68,68,0.3);  color: #fca5a5; }
        .alert-success { background: rgba(34,197,94,0.1);  border: 1px solid rgba(34,197,94,0.3);  color: #86efac; }

        /* Login box */
        .login-box {
            background: var(--card); border: 1px solid var(--border); border-radius: 18px;
            padding: 2.5rem; max-width: 400px; margin: 4rem auto;
        }
        .login-box h2 { font-size: 1.4rem; font-weight: 700; margin-bottom: 1.5rem; }
        .login-hint { font-size: 0.8rem; color: var(--muted); margin-top: 1rem; font-family: 'DM Mono', monospace; line-height: 1.6; }

        /* Forms */
        .panel { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 1.8rem; margin-bottom: 1.5rem; }
        .panel h3 { font-size: 1rem; font-weight: 600; margin-bottom: 1.2rem; color: var(--accent2); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; font-size: 0.8rem; color: var(--muted); margin-bottom: 6px; font-weight: 500; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%; padding: 10px 14px;
            background: var(--surface); color: var(--text);
            border: 1px solid var(--border); border-radius: 10px;
            font-family: 'Outfit', sans-serif; font-size: 0.9rem;
            transition: border-color 0.2s;
        }
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none; border-color: var(--accent);
        }
        .form-group textarea { resize: vertical; min-height: 70px; }
        .form-group select option { background: #111; }

        /* Buttons */
        .btn {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 10px 20px; border: none; border-radius: 10px; cursor: pointer;
            font-family: 'Outfit', sans-serif; font-size: 0.88rem; font-weight: 600;
            text-decoration: none; transition: opacity 0.2s, transform 0.15s;
        }
        .btn:hover { opacity: 0.85; transform: translateY(-1px); }
        .btn-primary { background: var(--accent); color: white; }
        .btn-success { background: #15803d; color: white; }
        .btn-danger  { background: transparent; color: var(--danger); border: 1px solid rgba(239,68,68,0.35); font-size: 0.78rem; padding: 5px 10px; }
        .btn-sm      { padding: 5px 12px; font-size: 0.78rem; border-radius: 7px; }
        .btn-toggle  { background: rgba(34,197,94,0.12); color: #86efac; border: 1px solid rgba(34,197,94,0.3); font-size: 0.78rem; padding: 5px 10px; border-radius: 7px; text-decoration: none; }

        /* Section header */
        .section-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
        .section-head h3 { font-size: 1rem; font-weight: 600; }
        .count { font-family: 'DM Mono', monospace; font-size: 0.72rem; color: var(--muted); }

        /* Task cards */
        .task-list { display: flex; flex-direction: column; gap: 10px; }
        .task-card {
            background: var(--card); border: 1px solid var(--border); border-radius: 12px;
            padding: 1rem 1.2rem; display: flex; align-items: center; gap: 1rem;
            border-left: 3px solid var(--border); transition: border-color 0.2s;
        }
        .task-card.alta  { border-left-color: #ef4444; }
        .task-card.media { border-left-color: #f59e0b; }
        .task-card.baja  { border-left-color: #22c55e; }
        .task-card.done  { opacity: 0.45; }
        .task-card.done .task-title { text-decoration: line-through; }
        .task-body { flex: 1; min-width: 0; }
        .task-title { font-size: 0.95rem; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .task-meta { font-size: 0.75rem; color: var(--muted); margin-top: 3px; font-family: 'DM Mono', monospace; }
        .task-desc { font-size: 0.82rem; color: var(--muted); margin-top: 4px; }
        .task-actions { display: flex; gap: 6px; flex-shrink: 0; }

        .prio-tag { display: inline-block; font-size: 0.65rem; font-family: 'DM Mono', monospace; padding: 2px 7px; border-radius: 99px; }
        .prio-alta  { background: rgba(239,68,68,0.15);  color: #fca5a5; }
        .prio-media { background: rgba(245,158,11,0.15); color: #fcd34d; }
        .prio-baja  { background: rgba(34,197,94,0.15);  color: #86efac; }

        .empty { text-align: center; padding: 2.5rem; color: var(--muted); font-size: 0.9rem; }

        /* Admin panel */
        .admin-panel { background: rgba(21,128,61,0.06); border: 1px solid rgba(21,128,61,0.2); border-radius: 16px; padding: 1.8rem; margin-top: 1.5rem; }
        .admin-panel h3 { color: #86efac; margin-bottom: 1.2rem; font-size: 1rem; }

        @keyframes fadeUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
        .wrap { animation: fadeUp 0.35s ease; }
    </style>
</head>
<body>
<div class="wrap">

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($msg):   ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

    <?php if (empty($_SESSION['uid'])): ?>
    <!-- ===== PANTALLA DE LOGIN ===== -->
    <div class="login-box">
        <h2>📋 TaskFlow</h2>
        <form action="index.php" method="POST">
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label>Usuario</label>
                <input type="text" name="username" placeholder="admin" required autofocus>
            </div>
            <div class="form-group">
                <label>Contraseña</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">Iniciar Sesión</button>
        </form>
        <p class="login-hint">
            Credenciales de prueba:<br>
            admin / admin123 &nbsp;·&nbsp; usuario1 / user123
        </p>
    </div>

    <?php else:
        $uid = (int)$_SESSION['uid'];
        $rol = $_SESSION['rol'];
    ?>
    <!-- ===== DASHBOARD ===== -->
    <div class="topbar">
        <div class="user-pill">
            <span><?= htmlspecialchars($_SESSION['username']) ?></span>
            <span class="role-badge <?= $rol ?>"><?= $rol ?></span>
        </div>
        <div style="display:flex;gap:1rem;">
            <a href="../index.php">← Menú principal</a>
            <a href="index.php?action=logout">Cerrar sesión</a>
        </div>
    </div>

    <div class="page-title">
        <h1>Gestión de Tareas</h1>
        <p>Sistema de tareas con roles y prioridades.</p>
    </div>

    <!-- Formulario nueva tarea -->
    <div class="panel">
        <h3>+ Nueva tarea</h3>
        <form action="index.php" method="POST">
            <input type="hidden" name="action" value="create_task">
            <div class="form-group">
                <label>Título *</label>
                <input type="text" name="titulo" placeholder="Escribe el título de la tarea..." required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Descripción</label>
                    <textarea name="descripcion" placeholder="Detalle opcional..."></textarea>
                </div>
                <div>
                    <div class="form-group">
                        <label>Prioridad</label>
                        <select name="prioridad">
                            <option value="baja">🟢 Baja</option>
                            <option value="media" selected>🟡 Media</option>
                            <option value="alta">🔴 Alta</option>
                        </select>
                    </div>
                    <?php if ($rol === 'admin'): ?>
                    <div class="form-group">
                        <label>Asignar a</label>
                        <select name="usuario_id">
                            <?php foreach ($db->query("SELECT id, username FROM usuarios")->fetchAll() as $u): ?>
                                <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['username']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary" style="width:100%;">Crear tarea</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Lista de tareas -->
    <?php
    if ($rol === 'admin') {
        $stmt = $db->query("SELECT t.*, u.username AS autor FROM tareas t JOIN usuarios u ON u.id = t.usuario_id ORDER BY t.completada ASC, t.id DESC");
    } else {
        $stmt = $db->prepare("SELECT t.*, u.username AS autor FROM tareas t JOIN usuarios u ON u.id = t.usuario_id WHERE t.usuario_id = ? ORDER BY t.completada ASC, t.id DESC");
        $stmt->execute([$uid]);
    }
    $tareas = $stmt->fetchAll();
    ?>
    <div>
        <div class="section-head">
            <h3>Tareas</h3>
            <span class="count"><?= count($tareas) ?> registros</span>
        </div>
        <div class="task-list">
        <?php if (empty($tareas)): ?>
            <div class="empty">No hay tareas aún. ¡Crea la primera! 🎯</div>
        <?php else: ?>
            <?php foreach ($tareas as $t): ?>
            <div class="task-card <?= $t['prioridad'] ?> <?= $t['completada'] ? 'done' : '' ?>">
                <div class="task-body">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span class="task-title"><?= htmlspecialchars($t['titulo']) ?></span>
                        <span class="prio-tag prio-<?= $t['prioridad'] ?>"><?= $t['prioridad'] ?></span>
                    </div>
                    <?php if ($t['descripcion']): ?>
                        <div class="task-desc"><?= htmlspecialchars($t['descripcion']) ?></div>
                    <?php endif; ?>
                    <div class="task-meta">Por: <?= htmlspecialchars($t['autor']) ?></div>
                </div>
                <div class="task-actions">
                    <a href="index.php?action=toggle&id=<?= $t['id'] ?>" class="btn-toggle">
                        <?= $t['completada'] ? '↩ Reabrir' : '✓ Listo' ?>
                    </a>
                    <a href="index.php?action=delete_task&id=<?= $t['id'] ?>" class="btn btn-danger" onclick="return confirm('¿Eliminar tarea?')">🗑</a>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
        </div>
    </div>

    <?php if ($rol === 'admin'): ?>
    <!-- Panel Admin -->
    <div class="admin-panel">
        <h3>👥 Registrar nuevo usuario</h3>
        <form action="index.php" method="POST">
            <input type="hidden" name="action" value="create_user">
            <div class="form-row">
                <div class="form-group">
                    <label>Nombre de usuario</label>
                    <input type="text" name="new_username" required>
                </div>
                <div class="form-group">
                    <label>Contraseña</label>
                    <input type="password" name="new_password" required>
                </div>
            </div>
            <div class="form-group">
                <label>Rol</label>
                <select name="new_rol">
                    <option value="2">Usuario Normal</option>
                    <option value="1">Administrador</option>
                </select>
            </div>
            <button type="submit" class="btn btn-success">Crear usuario</button>
        </form>
    </div>
    <?php endif; ?>

    <?php endif; ?>
</div>
</body>
</html>
