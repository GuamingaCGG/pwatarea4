<?php
// ejercicio04/index.php — Inventario CRUD
require_once __DIR__ . '/db.php';
$db = getDB();

// Crear tabla de productos
$db->exec("CREATE TABLE IF NOT EXISTS productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    categoria VARCHAR(60) DEFAULT 'General',
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

$error = ''; $msg = '';

// Añadir producto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $nombre    = trim($_POST['nombre'] ?? '');
    $categoria = trim($_POST['categoria'] ?? 'General');
    $precio    = (float)($_POST['precio'] ?? 0);
    $stock     = (int)($_POST['stock'] ?? 0);
    if ($nombre && $precio > 0 && $stock >= 0) {
        $db->prepare("INSERT INTO productos (nombre, categoria, precio, stock) VALUES (?, ?, ?, ?)")
           ->execute([$nombre, $categoria ?: 'General', $precio, $stock]);
        $msg = "Producto '{$nombre}' agregado.";
    } else { $error = "Completa todos los campos correctamente."; }
}

// Editar stock inline
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_stock'])) {
    $id    = (int)$_POST['prod_id'];
    $stock = (int)$_POST['new_stock'];
    if ($stock >= 0) {
        $db->prepare("UPDATE productos SET stock = ? WHERE id = ?")->execute([$stock, $id]);
        $msg = "Stock actualizado.";
    }
}

// Borrar producto
if (isset($_GET['del'])) {
    $db->prepare("DELETE FROM productos WHERE id = ?")->execute([(int)$_GET['del']]);
    header("Location: index.php"); exit;
}

// Obtener productos con filtros
$busqueda = trim($_GET['q'] ?? '');
if ($busqueda) {
    $stmt = $db->prepare("SELECT * FROM productos WHERE nombre LIKE ? OR categoria LIKE ? ORDER BY id DESC");
    $stmt->execute(["%$busqueda%", "%$busqueda%"]);
} else {
    $stmt = $db->query("SELECT * FROM productos ORDER BY id DESC");
}
$productos = $stmt->fetchAll();

// Stats
$stats = $db->query("SELECT COUNT(*) as total, SUM(precio*stock) as valor_total, SUM(stock) as total_stock FROM productos")->fetch();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Inventario CRUD</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet" />
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root { --bg:#06060a; --surface:#0e0e16; --border:#1a1a2e; --accent:#f97316; --text:#f1f5f9; --muted:#64748b; --card:#0d0d18; }
        body { font-family:'Outfit',sans-serif; background:var(--bg); color:var(--text); min-height:100vh; padding:2rem 1rem; }
        body::before { content:''; position:fixed; inset:0; background-image:linear-gradient(rgba(249,115,22,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(249,115,22,.03) 1px,transparent 1px); background-size:50px 50px; pointer-events:none; }
        .wrap { max-width:900px; margin:0 auto; position:relative; z-index:1; animation:fadeUp .35s ease; }
        @keyframes fadeUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
        .topbar { display:flex; align-items:center; justify-content:space-between; margin-bottom:2rem; }
        .topbar a { font-family:'DM Mono',monospace; font-size:.78rem; color:var(--muted); text-decoration:none; }
        .topbar a:hover { color:var(--text); }
        .page-title h1 { font-size:1.9rem; font-weight:700; letter-spacing:-.02em; margin-bottom:.3rem; }
        .page-title p  { color:var(--muted); font-size:.9rem; margin-bottom:1.5rem; }
        .alert { padding:12px 16px; border-radius:10px; font-size:.88rem; margin-bottom:1.5rem; }
        .alert-error   { background:rgba(239,68,68,.1);  border:1px solid rgba(239,68,68,.3);  color:#fca5a5; }
        .alert-success { background:rgba(34,197,94,.1);  border:1px solid rgba(34,197,94,.3);  color:#86efac; }
        /* Stats */
        .stats { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:1.5rem; }
        .stat-card { background:var(--card); border:1px solid var(--border); border-radius:12px; padding:1.2rem; }
        .stat-num { font-size:1.8rem; font-weight:700; color:var(--accent); }
        .stat-label { font-size:.72rem; color:var(--muted); font-family:'DM Mono',monospace; margin-top:3px; }
        /* Panel */
        .panel { background:var(--card); border:1px solid var(--border); border-radius:16px; padding:1.5rem; margin-bottom:1.5rem; }
        .panel h3 { font-size:.95rem; font-weight:600; color:var(--accent); margin-bottom:1rem; }
        .form-grid { display:grid; grid-template-columns:2fr 1fr 1fr 1fr auto; gap:10px; align-items:end; }
        .form-group { margin:0; }
        .form-group label { display:block; font-size:.75rem; color:var(--muted); margin-bottom:5px; }
        .form-group input, .form-group select { width:100%; padding:9px 12px; background:var(--surface); color:var(--text); border:1px solid var(--border); border-radius:9px; font-family:'Outfit',sans-serif; font-size:.88rem; }
        .form-group input:focus, .form-group select:focus { outline:none; border-color:var(--accent); }
        .btn { display:inline-flex; align-items:center; gap:5px; padding:9px 18px; border:none; border-radius:9px; cursor:pointer; font-family:'Outfit',sans-serif; font-size:.85rem; font-weight:600; text-decoration:none; transition:opacity .2s; }
        .btn:hover { opacity:.85; }
        .btn-primary { background:var(--accent); color:#0a0a0f; }
        .btn-danger  { background:transparent; color:#ef4444; border:1px solid rgba(239,68,68,.3); font-size:.75rem; padding:4px 9px; border-radius:6px; text-decoration:none; }
        /* Search */
        .search-row { display:flex; gap:10px; margin-bottom:1rem; }
        .search-row input { flex:1; padding:9px 14px; background:var(--surface); color:var(--text); border:1px solid var(--border); border-radius:10px; font-family:'Outfit',sans-serif; font-size:.88rem; }
        .search-row input:focus { outline:none; border-color:var(--accent); }
        /* Table */
        .table-wrap { background:var(--card); border:1px solid var(--border); border-radius:16px; overflow:hidden; }
        table { width:100%; border-collapse:collapse; }
        th { font-size:.68rem; font-family:'DM Mono',monospace; color:var(--muted); text-transform:uppercase; letter-spacing:.08em; padding:12px 1rem; text-align:left; border-bottom:1px solid var(--border); background:rgba(255,255,255,.01); }
        td { padding:11px 1rem; font-size:.88rem; border-bottom:1px solid var(--border); }
        tr:last-child td { border-bottom:none; }
        tr:hover td { background:rgba(255,255,255,.02); }
        .cat-pill { font-size:.68rem; font-family:'DM Mono',monospace; padding:3px 9px; border-radius:99px; background:rgba(249,115,22,.1); color:#fdba74; border:1px solid rgba(249,115,22,.2); }
        .stock-low { color:#ef4444; font-weight:600; }
        .stock-ok  { color:#86efac; }
        .stock-form { display:flex; gap:6px; align-items:center; }
        .stock-form input { width:70px; padding:5px 8px; background:var(--surface); color:var(--text); border:1px solid var(--border); border-radius:7px; font-size:.82rem; font-family:'DM Mono',monospace; }
        .btn-sm { padding:4px 10px; font-size:.75rem; border-radius:6px; border:none; background:var(--accent); color:#0a0a0f; cursor:pointer; font-family:'Outfit',monospace; font-weight:600; }
        .empty { text-align:center; padding:3rem; color:var(--muted); }
        .section-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:.8rem; }
        .section-head h3 { font-size:1rem; font-weight:600; }
        .count { font-family:'DM Mono',monospace; font-size:.72rem; color:var(--muted); }
    </style>
</head>
<body>
<div class="wrap">
    <div class="topbar"><a href="../index.php">← Menú principal</a></div>

    <div class="page-title">
        <h1>📦 Inventario CRUD</h1>
        <p>Gestión de productos con MySQL y PHP PDO.</p>
    </div>

    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($msg):   ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stats">
        <div class="stat-card"><div class="stat-num"><?= $stats['total'] ?? 0 ?></div><div class="stat-label">Productos</div></div>
        <div class="stat-card"><div class="stat-num"><?= number_format($stats['total_stock'] ?? 0) ?></div><div class="stat-label">Unidades totales</div></div>
        <div class="stat-card"><div class="stat-num">$<?= number_format($stats['valor_total'] ?? 0, 2) ?></div><div class="stat-label">Valor del inventario</div></div>
    </div>

    <!-- Formulario -->
    <div class="panel">
        <h3>+ Agregar producto</h3>
        <form action="index.php" method="POST">
            <div class="form-grid">
                <div class="form-group"><label>Nombre del producto *</label><input type="text" name="nombre" placeholder="Ej: Laptop Dell" required></div>
                <div class="form-group"><label>Categoría</label>
                    <select name="categoria">
                        <option>General</option><option>Electrónica</option><option>Ropa</option>
                        <option>Alimentos</option><option>Hogar</option><option>Herramientas</option>
                    </select>
                </div>
                <div class="form-group"><label>Precio ($) *</label><input type="number" name="precio" placeholder="0.00" step="0.01" min="0.01" required></div>
                <div class="form-group"><label>Stock *</label><input type="number" name="stock" placeholder="0" min="0" required></div>
                <button type="submit" name="add" class="btn btn-primary" style="height:40px;align-self:end">＋ Agregar</button>
            </div>
        </form>
    </div>

    <!-- Lista -->
    <div class="section-head">
        <h3>Productos registrados</h3>
        <span class="count"><?= count($productos) ?> productos</span>
    </div>
    <form method="GET" class="search-row" style="margin-bottom:1rem">
        <input type="text" name="q" placeholder="Buscar por nombre o categoría..." value="<?= htmlspecialchars($busqueda) ?>">
        <button type="submit" class="btn btn-primary" style="padding:9px 16px">Buscar</button>
        <?php if ($busqueda): ?><a href="index.php" class="btn" style="background:var(--border);color:var(--muted);padding:9px 14px">✕ Limpiar</a><?php endif; ?>
    </form>

    <div class="table-wrap">
    <?php if (empty($productos)): ?>
        <div class="empty">No hay productos<?= $busqueda ? " que coincidan con '{$busqueda}'" : ' registrados aún' ?>.</div>
    <?php else: ?>
        <table>
            <thead>
                <tr><th>#</th><th>Producto</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Acción</th></tr>
            </thead>
            <tbody>
            <?php foreach ($productos as $i => $p): ?>
                <tr>
                    <td style="font-family:'DM Mono',monospace;font-size:.75rem;color:var(--muted)"><?= $i+1 ?></td>
                    <td style="font-weight:600"><?= htmlspecialchars($p['nombre']) ?></td>
                    <td><span class="cat-pill"><?= htmlspecialchars($p['categoria']) ?></span></td>
                    <td style="font-family:'DM Mono',monospace">$<?= number_format($p['precio'],2) ?></td>
                    <td>
                        <form method="POST" class="stock-form" style="display:flex;gap:5px">
                            <input type="hidden" name="prod_id" value="<?= $p['id'] ?>">
                            <input type="number" name="new_stock" value="<?= $p['stock'] ?>" min="0" class="<?= $p['stock'] <= 5 ? 'stock-low' : 'stock-ok' ?>">
                            <button type="submit" name="edit_stock" class="btn-sm">✓</button>
                        </form>
                    </td>
                    <td><a href="index.php?del=<?= $p['id'] ?>" class="btn-danger" onclick="return confirm('¿Eliminar producto?')">🗑 Eliminar</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    </div>
</div>
</body>
</html>
