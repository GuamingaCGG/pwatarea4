<?php // ejercicio03/index.php ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Presupuesto Dinámico</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet" />
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root { --bg:#06060a; --surface:#0e0e16; --border:#1a1a2e; --accent:#84cc16; --text:#f1f5f9; --muted:#64748b; --card:#0d0d18; }
        body { font-family:'Outfit',sans-serif; background:var(--bg); color:var(--text); min-height:100vh; padding:2rem 1rem; }
        body::before { content:''; position:fixed; inset:0; background-image:linear-gradient(rgba(132,204,22,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(132,204,22,0.03) 1px,transparent 1px); background-size:50px 50px; pointer-events:none; }
        .wrap { max-width:640px; margin:0 auto; position:relative; z-index:1; animation:fadeUp .35s ease; }
        @keyframes fadeUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
        .topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:2rem; }
        .topbar a { font-family:'DM Mono',monospace; font-size:.78rem; color:var(--muted); text-decoration:none; }
        .topbar a:hover { color:var(--text); }
        .page-title h1 { font-size:1.9rem; font-weight:700; letter-spacing:-.02em; margin-bottom:.3rem; }
        .page-title p  { color:var(--muted); font-size:.9rem; margin-bottom:2rem; }

        /* Budget summary */
        .budget-hero { background:var(--card); border:1px solid var(--border); border-radius:20px; padding:2rem; margin-bottom:1.5rem; text-align:center; }
        .total-label { font-family:'DM Mono',monospace; font-size:.72rem; color:var(--muted); text-transform:uppercase; letter-spacing:.12em; }
        .total-amount { font-size:3.5rem; font-weight:700; color:var(--accent); letter-spacing:-.04em; line-height:1.1; margin:.5rem 0; }
        .total-count { font-size:.85rem; color:var(--muted); }

        /* Progress bar */
        .budget-limit { margin-top:1rem; }
        .limit-row { display:flex; justify-content:space-between; font-size:.78rem; color:var(--muted); margin-bottom:6px; font-family:'DM Mono',monospace; }
        .bar-track { background:var(--border); border-radius:99px; height:6px; overflow:hidden; }
        .bar-fill { height:100%; background:var(--accent); border-radius:99px; transition:width .4s ease; }
        .bar-fill.warning { background:#f59e0b; }
        .bar-fill.danger  { background:#ef4444; }

        /* Input form */
        .add-form { background:var(--card); border:1px solid var(--border); border-radius:16px; padding:1.5rem; margin-bottom:1.5rem; }
        .add-form h3 { font-size:.95rem; font-weight:600; color:var(--accent); margin-bottom:1rem; }
        .input-row { display:grid; grid-template-columns:1fr auto auto; gap:10px; align-items:end; }
        .form-group { margin-bottom:0; }
        .form-group label { display:block; font-size:.75rem; color:var(--muted); margin-bottom:5px; }
        .form-group input, .form-group select {
            width:100%; padding:10px 14px; background:var(--surface); color:var(--text);
            border:1px solid var(--border); border-radius:10px;
            font-family:'Outfit',sans-serif; font-size:.9rem; transition:border-color .2s;
        }
        .form-group input:focus, .form-group select:focus { outline:none; border-color:var(--accent); }
        .btn { display:inline-flex; align-items:center; gap:6px; padding:10px 18px; border:none; border-radius:10px; cursor:pointer; font-family:'Outfit',sans-serif; font-size:.88rem; font-weight:600; transition:opacity .2s; }
        .btn:hover { opacity:.85; }
        .btn-primary { background:var(--accent); color:#0a0a0f; }
        .btn-ghost { background:transparent; color:var(--muted); border:1px solid var(--border); font-size:.8rem; padding:6px 14px; }

        /* Category filter */
        .cat-filter { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:1rem; }
        .cat-chip { font-family:'DM Mono',monospace; font-size:.68rem; padding:4px 12px; border-radius:99px; border:1px solid var(--border); color:var(--muted); cursor:pointer; background:transparent; transition:all .2s; }
        .cat-chip.active, .cat-chip:hover { border-color:var(--accent); color:var(--accent); background:rgba(132,204,22,.08); }

        /* Expense list */
        .expense-list { display:flex; flex-direction:column; gap:8px; }
        .expense-item {
            background:var(--card); border:1px solid var(--border); border-radius:12px;
            padding:1rem 1.2rem; display:flex; align-items:center; gap:12px;
            animation:slideIn .25s ease;
        }
        @keyframes slideIn { from{opacity:0;transform:translateX(-10px)} to{opacity:1;transform:translateX(0)} }
        .exp-icon { font-size:1.4rem; flex-shrink:0; }
        .exp-body { flex:1; min-width:0; }
        .exp-name { font-size:.92rem; font-weight:600; }
        .exp-cat  { font-size:.72rem; color:var(--muted); font-family:'DM Mono',monospace; margin-top:2px; }
        .exp-amount { font-family:'DM Mono',monospace; font-size:1rem; font-weight:700; color:var(--accent); flex-shrink:0; }
        .btn-del { background:transparent; border:none; color:var(--muted); cursor:pointer; font-size:1rem; padding:4px 6px; border-radius:6px; transition:color .15s; }
        .btn-del:hover { color:#ef4444; }

        .empty { text-align:center; padding:2.5rem; color:var(--muted); font-size:.9rem; }

        .section-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:.8rem; }
        .section-head h3 { font-size:1rem; font-weight:600; }
    </style>
</head>
<body>
<div class="wrap">
    <div class="topbar">
        <a href="../index.php">← Menú principal</a>
    </div>

    <div class="page-title">
        <h1>💰 Presupuesto</h1>
        <p>Calculadora de gastos dinámica con categorías.</p>
    </div>

    <!-- Resumen -->
    <div class="budget-hero">
        <div class="total-label">Total gastado</div>
        <div class="total-amount">$<span id="totalMonto">0.00</span></div>
        <div class="total-count"><span id="totalItems">0</span> gastos registrados</div>
        <div class="budget-limit">
            <div class="limit-row">
                <span>Presupuesto disponible</span>
                <span>$<span id="limiteText">500.00</span></span>
            </div>
            <div class="bar-track"><div class="bar-fill" id="barraProgreso" style="width:0%"></div></div>
        </div>
    </div>

    <!-- Formulario -->
    <div class="add-form">
        <h3>+ Agregar gasto</h3>
        <div class="input-row">
            <div class="form-group"><label>Descripción</label><input type="text" id="inputNombre" placeholder="Ej: Almuerzo, Netflix..."></div>
            <div class="form-group"><label>Monto ($)</label><input type="number" id="inputMonto" placeholder="0.00" step="0.01" min="0.01" style="width:110px"></div>
            <div class="form-group"><label>Categoría</label>
                <select id="inputCat" style="width:130px">
                    <option value="🍔 Comida">🍔 Comida</option>
                    <option value="🚗 Transporte">🚗 Transporte</option>
                    <option value="📱 Tech">📱 Tech</option>
                    <option value="🎮 Entretenimiento">🎮 Entretenimiento</option>
                    <option value="🏠 Hogar">🏠 Hogar</option>
                    <option value="💊 Salud">💊 Salud</option>
                    <option value="📦 Otro">📦 Otro</option>
                </select>
            </div>
        </div>
        <div style="display:flex;gap:10px;margin-top:1rem">
            <button class="btn btn-primary" onclick="agregarGasto()">Agregar</button>
            <div class="form-group" style="display:flex;align-items:center;gap:8px">
                <label style="white-space:nowrap">Límite: $</label>
                <input type="number" id="inputLimite" value="500" min="1" step="10" style="width:90px;padding:6px 10px" oninput="actualizarBarra()">
            </div>
            <button class="btn btn-ghost" onclick="limpiarTodo()">Limpiar todo</button>
        </div>
    </div>

    <!-- Lista -->
    <div>
        <div class="section-head">
            <h3>Historial de gastos</h3>
            <div class="cat-filter" id="filtros">
                <button class="cat-chip active" onclick="filtrar('todos', this)">Todos</button>
            </div>
        </div>
        <div class="expense-list" id="lista">
            <div class="empty" id="emptyMsg">Aún no hay gastos. ¡Agrega el primero!</div>
        </div>
    </div>
</div>

<script>
let gastos = JSON.parse(localStorage.getItem('gastos_ej03') || '[]');
let filtroActual = 'todos';

function guardar() { localStorage.setItem('gastos_ej03', JSON.stringify(gastos)); }

function agregarGasto() {
    const nombre = document.getElementById('inputNombre').value.trim();
    const monto  = parseFloat(document.getElementById('inputMonto').value);
    const cat    = document.getElementById('inputCat').value;
    if (!nombre || isNaN(monto) || monto <= 0) { alert('Completa todos los campos correctamente.'); return; }
    gastos.push({ id: Date.now(), nombre, monto, cat });
    guardar(); renderizar();
    document.getElementById('inputNombre').value = '';
    document.getElementById('inputMonto').value  = '';
    document.getElementById('inputNombre').focus();
}

function eliminarGasto(id) {
    gastos = gastos.filter(g => g.id !== id);
    guardar(); renderizar();
}

function limpiarTodo() {
    if (!confirm('¿Eliminar todos los gastos?')) return;
    gastos = []; guardar(); renderizar();
}

function filtrar(cat, btn) {
    filtroActual = cat;
    document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    renderLista();
}

function actualizarBarra() {
    const total  = gastos.reduce((s, g) => s + g.monto, 0);
    const limite = parseFloat(document.getElementById('inputLimite').value) || 500;
    const pct    = Math.min((total / limite) * 100, 100);
    const barra  = document.getElementById('barraProgreso');
    barra.style.width = pct + '%';
    barra.className = 'bar-fill' + (pct >= 90 ? ' danger' : pct >= 70 ? ' warning' : '');
    document.getElementById('limiteText').textContent = limite.toFixed(2);
}

function renderizar() {
    const total = gastos.reduce((s, g) => s + g.monto, 0);
    document.getElementById('totalMonto').textContent = total.toFixed(2);
    document.getElementById('totalItems').textContent = gastos.length;
    actualizarBarra();
    // Actualizar filtros
    const cats = [...new Set(gastos.map(g => g.cat))];
    const fc = document.getElementById('filtros');
    fc.innerHTML = `<button class="cat-chip ${filtroActual==='todos'?'active':''}" onclick="filtrar('todos',this)">Todos</button>`;
    cats.forEach(c => {
        const btn = document.createElement('button');
        btn.className = 'cat-chip' + (filtroActual === c ? ' active' : '');
        btn.textContent = c;
        btn.onclick = function() { filtrar(c, this); };
        fc.appendChild(btn);
    });
    renderLista();
}

function renderLista() {
    const lista = document.getElementById('lista');
    const filtrados = filtroActual === 'todos' ? gastos : gastos.filter(g => g.cat === filtroActual);
    const empty = document.getElementById('emptyMsg');
    if (filtrados.length === 0) {
        lista.innerHTML = '';
        lista.appendChild(empty || Object.assign(document.createElement('div'), { className:'empty', textContent:'Sin gastos en esta categoría.' }));
        return;
    }
    lista.innerHTML = [...filtrados].reverse().map(g => `
        <div class="expense-item">
            <span class="exp-icon">${g.cat.split(' ')[0]}</span>
            <div class="exp-body">
                <div class="exp-name">${escHtml(g.nombre)}</div>
                <div class="exp-cat">${escHtml(g.cat)}</div>
            </div>
            <span class="exp-amount">$${g.monto.toFixed(2)}</span>
            <button class="btn-del" onclick="eliminarGasto(${g.id})" title="Eliminar">✕</button>
        </div>
    `).join('');
}

function escHtml(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// Enter para agregar
document.addEventListener('keydown', e => { if (e.key === 'Enter' && document.activeElement.id !== 'inputLimite') agregarGasto(); });

renderizar();
</script>
</body>
</html>
