<?php
// ejercicio05/index.php — Bloc de Notas con archivos
$dir    = __DIR__ . '/notas/';
$error  = ''; $msg = '';

// Crear directorio si no existe
if (!is_dir($dir)) mkdir($dir, 0755, true);

// Acción: guardar nota
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $accion = $_POST['action'];

    if ($accion === 'guardar') {
        $nombre = preg_replace('/[^a-zA-Z0-9_\-]/', '', trim($_POST['nombre'] ?? 'nota'));
        $nombre = $nombre ?: 'nota';
        $texto  = $_POST['texto'] ?? '';
        file_put_contents($dir . $nombre . '.txt', $texto);
        $msg = "Nota '{$nombre}' guardada.";
    }

    if ($accion === 'nueva') {
        $nombre = preg_replace('/[^a-zA-Z0-9_\-]/', '', trim($_POST['nombre'] ?? ''));
        if ($nombre) {
            $archivo = $dir . $nombre . '.txt';
            if (!file_exists($archivo)) {
                file_put_contents($archivo, '');
                $msg = "Nota '{$nombre}' creada.";
            } else { $error = "Ya existe una nota con ese nombre."; }
        } else { $error = "El nombre no puede estar vacío."; }
    }
}

// Eliminar nota
if (isset($_GET['del'])) {
    $nombre = preg_replace('/[^a-zA-Z0-9_\-]/', '', $_GET['del']);
    $archivo = $dir . $nombre . '.txt';
    if (file_exists($archivo)) { unlink($archivo); $msg = "Nota eliminada."; }
    header("Location: index.php"); exit;
}

// Nota activa
$nota_activa = preg_replace('/[^a-zA-Z0-9_\-]/', '', $_GET['nota'] ?? '');
$archivos = glob($dir . '*.txt') ?: [];
$notas = array_map(fn($f) => pathinfo($f, PATHINFO_FILENAME), $archivos);

// Si no hay nota seleccionada, usar la primera
if (!$nota_activa && count($notas) > 0) $nota_activa = $notas[0];

// Si no hay ninguna nota, crear una por defecto
if (count($notas) === 0) {
    file_put_contents($dir . 'mis-notas.txt', "Escribe aquí tus notas...\n");
    $notas[] = 'mis-notas';
    $nota_activa = 'mis-notas';
}

$contenido = file_exists($dir . $nota_activa . '.txt') ? file_get_contents($dir . $nota_activa . '.txt') : '';
$palabras  = $contenido ? str_word_count($contenido) : 0;
$lineas    = $contenido ? count(explode("\n", $contenido)) : 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Bloc de Notas</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet" />
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root { --bg:#06060a; --surface:#0e0e16; --border:#1a1a2e; --accent:#ec4899; --text:#f1f5f9; --muted:#64748b; --card:#0d0d18; }
        body { font-family:'Outfit',sans-serif; background:var(--bg); color:var(--text); height:100vh; display:flex; flex-direction:column; overflow:hidden; }
        body::before { content:''; position:fixed; inset:0; background-image:linear-gradient(rgba(236,72,153,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(236,72,153,.03) 1px,transparent 1px); background-size:50px 50px; pointer-events:none; }
        /* Layout */
        .app { display:flex; flex:1; min-height:0; position:relative; z-index:1; }
        /* Sidebar */
        .sidebar { width:240px; flex-shrink:0; background:var(--card); border-right:1px solid var(--border); display:flex; flex-direction:column; }
        .sidebar-head { padding:1.2rem; border-bottom:1px solid var(--border); }
        .sidebar-head h2 { font-size:1rem; font-weight:700; color:var(--accent); }
        .sidebar-head p  { font-size:.72rem; color:var(--muted); margin-top:2px; font-family:'DM Mono',monospace; }
        .sidebar-body { flex:1; overflow-y:auto; padding:.5rem; }
        .nota-item { display:flex; align-items:center; justify-content:space-between; padding:8px 10px; border-radius:8px; cursor:pointer; text-decoration:none; color:var(--text); transition:background .15s; }
        .nota-item:hover { background:var(--border); }
        .nota-item.active { background:rgba(236,72,153,.12); color:var(--accent); }
        .nota-name { font-size:.85rem; font-weight:500; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        .del-btn { color:var(--muted); font-size:.8rem; padding:2px 5px; border-radius:4px; text-decoration:none; opacity:0; transition:opacity .15s; }
        .nota-item:hover .del-btn { opacity:1; }
        .del-btn:hover { color:#ef4444; }
        /* Nueva nota */
        .new-note { padding:.8rem; border-top:1px solid var(--border); }
        .new-note form { display:flex; gap:6px; }
        .new-note input { flex:1; padding:7px 10px; background:var(--surface); color:var(--text); border:1px solid var(--border); border-radius:8px; font-size:.8rem; font-family:'Outfit',sans-serif; }
        .new-note input:focus { outline:none; border-color:var(--accent); }
        .new-note button { padding:7px 12px; background:var(--accent); color:white; border:none; border-radius:8px; font-size:.8rem; font-weight:600; cursor:pointer; }
        /* Editor */
        .editor-wrap { flex:1; display:flex; flex-direction:column; min-width:0; }
        .editor-bar { padding:.8rem 1.5rem; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; gap:1rem; flex-wrap:wrap; }
        .editor-title { font-family:'DM Mono',monospace; font-size:.9rem; color:var(--accent); font-weight:500; }
        .editor-meta { font-family:'DM Mono',monospace; font-size:.72rem; color:var(--muted); display:flex; gap:1rem; }
        .editor-actions { display:flex; gap:.8rem; align-items:center; }
        .editor-actions a { font-family:'DM Mono',monospace; font-size:.75rem; color:var(--muted); text-decoration:none; }
        .editor-actions a:hover { color:var(--text); }
        .editor-main { flex:1; padding:1.5rem; display:flex; flex-direction:column; }
        textarea {
            flex:1; width:100%; background:transparent; color:var(--text); border:none; resize:none;
            font-family:'DM Mono',monospace; font-size:.95rem; line-height:1.8; outline:none;
            caret-color:var(--accent);
        }
        .save-bar { padding:.8rem 1.5rem; border-top:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; }
        .save-bar span { font-size:.75rem; color:var(--muted); font-family:'DM Mono',monospace; }
        .btn-save { padding:9px 24px; background:var(--accent); color:white; border:none; border-radius:10px; font-weight:600; font-size:.88rem; cursor:pointer; transition:opacity .2s; }
        .btn-save:hover { opacity:.85; }
        /* Alerts */
        .alert-bar { padding:10px 1.5rem; font-size:.85rem; }
        .alert-error   { background:rgba(239,68,68,.1);  color:#fca5a5; border-bottom:1px solid rgba(239,68,68,.2); }
        .alert-success { background:rgba(34,197,94,.1);  color:#86efac; border-bottom:1px solid rgba(34,197,94,.2); }
        /* Topnav */
        .topnav { display:flex; align-items:center; justify-content:space-between; padding:.7rem 1.2rem; border-bottom:1px solid var(--border); background:var(--card); position:relative; z-index:1; }
        .topnav a { font-family:'DM Mono',monospace; font-size:.75rem; color:var(--muted); text-decoration:none; }
        .topnav a:hover { color:var(--text); }
        .topnav .brand { font-family:'DM Mono',monospace; font-size:.82rem; color:var(--accent); }
    </style>
</head>
<body>

<div class="topnav">
    <span class="brand">📝 Bloc de Notas</span>
    <a href="../index.php">← Menú principal</a>
</div>

<?php if ($error): ?><div class="alert-bar alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($msg):   ?><div class="alert-bar alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

<div class="app">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-head">
            <h2>Mis Notas</h2>
            <p><?= count($notas) ?> archivo<?= count($notas) !== 1 ? 's' : '' ?></p>
        </div>
        <div class="sidebar-body">
            <?php foreach ($notas as $n): ?>
            <a href="index.php?nota=<?= urlencode($n) ?>" class="nota-item <?= $n === $nota_activa ? 'active' : '' ?>">
                <span class="nota-name">📄 <?= htmlspecialchars($n) ?></span>
                <a href="index.php?del=<?= urlencode($n) ?>" class="del-btn" onclick="return confirm('¿Eliminar nota?')" title="Eliminar">✕</a>
            </a>
            <?php endforeach; ?>
        </div>
        <div class="new-note">
            <form action="index.php?nota=<?= urlencode($nota_activa) ?>" method="POST">
                <input type="hidden" name="action" value="nueva">
                <input type="text" name="nombre" placeholder="nueva-nota" pattern="[a-zA-Z0-9_\-]+" title="Solo letras, números, - y _">
                <button type="submit">＋</button>
            </form>
        </div>
    </aside>

    <!-- Editor -->
    <div class="editor-wrap">
        <div class="editor-bar">
            <span class="editor-title"><?= htmlspecialchars($nota_activa) ?>.txt</span>
            <div class="editor-meta">
                <span id="palabras"><?= $palabras ?> palabras</span>
                <span id="lineas"><?= $lineas ?> líneas</span>
                <span id="chars"><?= strlen($contenido) ?> chars</span>
            </div>
        </div>
        <form action="index.php?nota=<?= urlencode($nota_activa) ?>" method="POST" class="editor-main" id="editorForm">
            <input type="hidden" name="action" value="guardar">
            <input type="hidden" name="nombre" value="<?= htmlspecialchars($nota_activa) ?>">
            <textarea name="texto" id="editorTexto" placeholder="Empieza a escribir..."><?= htmlspecialchars($contenido) ?></textarea>
        </form>
        <div class="save-bar">
            <span id="savedStatus">Ctrl+S para guardar</span>
            <button class="btn-save" onclick="document.getElementById('editorForm').submit()">💾 Guardar</button>
        </div>
    </div>
</div>

<script>
const textarea = document.getElementById('editorTexto');
const status   = document.getElementById('savedStatus');
let autoTimer;

function updateStats() {
    const txt = textarea.value;
    document.getElementById('chars').textContent    = txt.length + ' chars';
    document.getElementById('palabras').textContent = (txt.trim() ? txt.trim().split(/\s+/).length : 0) + ' palabras';
    document.getElementById('lineas').textContent   = txt.split('\n').length + ' líneas';
}

textarea.addEventListener('input', () => {
    updateStats();
    status.textContent = 'Sin guardar...';
    clearTimeout(autoTimer);
    autoTimer = setTimeout(() => {
        document.getElementById('editorForm').submit();
    }, 4000);
});

document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        clearTimeout(autoTimer);
        document.getElementById('editorForm').submit();
    }
});
</script>
</body>
</html>
