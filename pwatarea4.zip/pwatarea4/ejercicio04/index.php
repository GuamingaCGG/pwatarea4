<?php
// ejercicio04/index.php
require_once __DIR__ . '/../ejercicio01/db.php';
$db = getDB();

// Crear tabla específica del inventario
$db->exec("CREATE TABLE IF NOT EXISTS productos (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(100) NOT NULL, precio DECIMAL(10,2) NOT NULL, stock INT NOT NULL)");

// Añadir producto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $db->prepare("INSERT INTO productos (nombre, precio, stock) VALUES (?, ?, ?)")
       ->execute([trim($_POST['nombre']), $_POST['precio'], $_POST['stock']]);
    header("Location: index.php"); exit;
}

// Borrar producto
if (isset($_GET['del'])) {
    $db->prepare("DELETE FROM productos WHERE id = ?")->execute([(int)$_GET['del']]);
    header("Location: index.php"); exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"><title>Ejercicio 04 — Inventario</title>
    <style>
        body { font-family: sans-serif; background: #090d16; color: white; padding: 20px; }
        .box { max-width: 600px; margin: 0 auto; background: #111827; padding: 20px; border-radius: 8px; }
        .grid { display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 8px; margin-bottom: 20px; }
        input, button { padding: 8px; background: #1f2937; color: white; border: 1px solid #374151; border-radius: 4px; }
        button { background: #7c3aed; cursor: pointer; border: none; }
        table { width: 100%; border-collapse: collapse; } td, th { padding: 10px; text-align: left; border-bottom: 1px solid #374151; }
    </style>
</head>
<body>
<div class="box">
    <h2> CRUD de Inventario (MySQL) </h2>
    <form action="index.php" method="POST" class="grid">
        <input type="text" name="nombre" placeholder="Producto" required>
        <input type="number" name="precio" placeholder="Precio" step="0.01" required>
        <input type="number" name="stock" placeholder="Stock" required>
        <button type="submit" name="add">＋</button>
    </form>
    <table>
        <tr><th>Nombre</th><th>Precio</th><th>Stock</th><th>Acción</th></tr>
        <?php foreach ($db->query("SELECT * FROM productos ORDER BY id DESC")->fetchAll() as $p): ?>
            <tr><td><?= htmlspecialchars($p['nombre']) ?></td><td>$<?= $p['precio'] ?></td><td><?= $p['stock'] ?> u</td><td><a href="index.php?del=<?= $p['id'] ?>" style="color:red; text-decoration:none;">🗑️</a></td></tr>
        <?php endforeach; ?>
    </table>
    <br><a href="../index.php" style="color:#94a3b8;"> Volver al Menú</a>
</div>
</body>
</html>