<?php
// ejercicio01/index.php
session_start();
require_once __DIR__ . '/db.php';
$db = getDB();

$error = '';
$msg = '';

// 1. Iniciar Sesión
if (isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $db->prepare("SELECT u.*, r.nombre AS rol FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE u.username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['uid'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['rol'] = $user['rol'];
        header("Location: index.php");
        exit;
    } else {
        $error = "Credenciales incorrectas.";
    }
}

// 2. Cerrar Sesión
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header("Location: index.php");
    exit;
}

// Acciones protegidas (Requieren autenticación)
if (!empty($_SESSION['uid'])) {
    $uid = (int)$_SESSION['uid'];
    $rol = $_SESSION['rol'];

    // 3. Crear Tarea
    if (isset($_POST['action']) && $_POST['action'] === 'create_task') {
        $titulo = trim($_POST['titulo'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $prioridad = $_POST['prioridad'] ?? 'media';
        
        //
        $asignado = ($rol === 'admin' && !empty($_POST['usuario_id'])) ? (int)$_POST['usuario_id'] : $uid;

        if ($titulo) {
            $stmt = $db->prepare("INSERT INTO tareas (titulo, descripcion, prioridad, usuario_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([$titulo, $descripcion, $prioridad, $asignado]);
            $msg = "Tarea creada con éxito.";
        } else {
            $error = "El título es obligatorio.";
        }
    }

    // 4. Cambiar Estado 
    if (isset($_GET['action']) && $_GET['action'] === 'toggle') {
        $tid = (int)$_GET['id'];
        
        // Validar propiedad o permisos
        $stmt = $db->prepare("SELECT * FROM tareas WHERE id = ?");
        $stmt->execute([$tid]);
        $tarea = $stmt->fetch();

        if ($tarea && ($rol === 'admin' || $tarea['usuario_id'] == $uid)) {
            $nuevoEstado = $tarea['completada'] ? 0 : 1;
            $db->prepare("UPDATE tareas SET completada = ? WHERE id = ?")->execute([$nuevoEstado, $tid]);
        }
        header("Location: index.php");
        exit;
    }

    // 5. Eliminar Tarea
    if (isset($_GET['action']) && $_GET['action'] === 'delete_task') {
        $tid = (int)$_GET['id'];
        $stmt = $db->prepare("SELECT * FROM tareas WHERE id = ?");
        $stmt->execute([$tid]);
        $tarea = $stmt->fetch();

        if ($tarea && ($rol === 'admin' || $tarea['usuario_id'] == $uid)) {
            $db->prepare("DELETE FROM tareas WHERE id = ?")->execute([$tid]);
            $msg = "Tarea eliminada.";
        }
    }

    // 6. Crear Usuario (Solo Admin)
    if (isset($_POST['action']) && $_POST['action'] === 'create_user' && $rol === 'admin') {
        $new_user = trim($_POST['new_username'] ?? '');
        $new_pass = $_POST['new_password'] ?? '';
        $new_rol_id = (int)($_POST['new_rol'] ?? 2);

        if ($new_user && $new_pass) {
            try {
                $hash = password_hash($new_pass, PASSWORD_BCRYPT);
                $db->prepare("INSERT INTO usuarios (username, password, rol_id) VALUES (?, ?, ?)")->execute([$new_user, $hash, $new_rol_id]);
                $msg = "Usuario creado correctamente.";
            } catch (PDOException $e) {
                $error = "El usuario ya existe.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title> Gestión de Tareas </title>
    <style>
        body { font-family: sans-serif; background: #f4f6f9; color: #333; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input, .form-group textarea, .form-group select { width: 100%; padding: 8px; box-sizing: border-box; }
        .btn { background: #5046e4; color: #fff; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; }
        .btn-danger { background: #ef4444; }
        .btn-sm { padding: 4px 8px; font-size: 0.85rem; text-decoration: none; border-radius: 3px; }
        .alert { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .alert-error { background: #fee2e2; color: #b91c1c; }
        .alert-success { background: #dcfce7; color: #15803d; }
        .task-card { border-left: 4px solid #6b7280; padding: 10px; margin-bottom: 10px; background: #f9fafb; display: flex; justify-content: space-between; align-items: center; }
        .task-card.alta { border-left-color: #ef4444; }
        .task-card.media { border-left-color: #f59e0b; }
        .task-card.baja { border-left-color: #22c55e; }
        .task-card.done { opacity: 0.6; text-decoration: line-through; }
        .meta { font-size: 0.8rem; color: #666; }
        .admin-section { background: #f0fdf4; border: 1px solid #bbf7d0; padding: 15px; margin-top: 30px; border-radius: 6px; }
    </style>
</head>
<body>

<div class="container">
    <h2> TaskFlow — Gestión de Tareas</h2>

    <?php if ($error): ?> <div class="alert alert-error"><?= $error ?></div> <?php endif; ?>
    <?php if ($msg): ?> <div class="alert alert-success"><?= $msg ?></div> <?php endif; ?>

    <?php if (empty($_SESSION['uid'])): ?>
        <h3>Iniciar Sesión</h3>
        <form action="index.php" method="POST">
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label>Usuario</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label>Contraseña</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" class="btn">Ingresar</button>
        </form>
        <p style="font-size:0.85rem; color:#666;">Credenciales de prueba: <strong>admin / admin123</strong> o <strong>usuario1 / user123</strong></p>

    <?php else: ?>
        <p>Bienvenido, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong> (Rol: <em><?= htmlspecialchars($_SESSION['rol']) ?></em>) | <a href="index.php?action=logout">Cerrar Sesión</a></p>
        <hr>

        <h3>+ Nueva Tarea</h3>
        <form action="index.php" method="POST">
            <input type="hidden" name="action" value="create_task">
            <div class="form-group">
                <label>Título</label>
                <input type="text" name="titulo" required>
            </div>
            <div class="form-group">
                <label>Descripción</label>
                <textarea name="descripcion" rows="2"></textarea>
            </div>
            <div class="form-group">
                <label>Prioridad</label>
                <select name="prioridad">
                    <option value="baja">Baja</option>
                    <option value="media" selected>Media</option>
                    <option value="alta">Alta</option>
                </select>
            </div>

            <?php if ($_SESSION['rol'] === 'admin'): ?>
                <div class="form-group">
                    <label>Asignar a</label>
                    <select name="usuario_id">
                        <?php
                        $users = $db->query("SELECT id, username FROM usuarios")->fetchAll();
                        foreach ($users as $u) {
                            echo "<option value='{$u['id']}'>{$u['username']}</option>";
                        }
                        ?>
                    </select>
                </div>
            <?php endif; ?>

            <button type="submit" class="btn">Guardar Tarea</button>
        </form>

        <hr>

        <h3>Mis Tareas Pendientes</h3>
        <?php
        // Carga de datos condicional según el rol
        if ($_SESSION['rol'] === 'admin') {
            // El Admin ve todo de todos
            $stmt = $db->query("SELECT t.*, u.username AS autor FROM tareas t JOIN usuarios u ON u.id = t.usuario_id ORDER BY t.id DESC");
        } else {
            // El usuario regular ve únicamente lo propio
            $stmt = $db->prepare("SELECT t.*, u.username AS autor FROM tareas t JOIN usuarios u ON u.id = t.usuario_id WHERE t.usuario_id = ? ORDER BY t.id DESC");
            $stmt->execute([$_SESSION['uid']]);
        }
        $tareas = $stmt->fetchAll();

        if (count($tareas) === 0):
            echo "<p>No hay tareas registradas.</p>";
        else:
            foreach ($tareas as $t):
                $claseDone = $t['completada'] ? 'done' : '';
                $textoCheck = $t['completada'] ? 'Pendiente' : ' Completar';
        ?>
                <div class="task-card <?= $t['prioridad'] ?> <?= $claseDone ?>">
                    <div>
                        <strong><?= htmlspecialchars($t['titulo']) ?></strong> - <span class="meta">[Prioridad: <?= $t['prioridad'] ?> | Por: <?= htmlspecialchars($t['autor']) ?>]</span>
                        <p style="margin: 5px 0 0 0; font-size: 0.9rem;"><?= htmlspecialchars($t['descripcion']) ?></p>
                    </div>
                    <div>
                        <a href="index.php?action=toggle&id=<?= $t['id'] ?>" class="btn btn-sm" style="background:#22c55e; color:white;"><?= $textoCheck ?></a>
                        <a href="index.php?action=delete_task&id=<?= $t['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Seguro?')">🗑 Eliminar</a>
                    </div>
                </div>
        <?php 
            endforeach;
        endif; 
        ?>

        <?php if ($_SESSION['rol'] === 'admin'): ?>
            <div class="admin-section">
                <h3>👥 Panel de Control: Registrar Nuevo Usuario</h3>
                <form action="index.php" method="POST">
                    <input type="hidden" name="action" value="create_user">
                    <div class="form-group">
                        <label>Nombre de Usuario</label>
                        <input type="text" name="new_username" required>
                    </div>
                    <div class="form-group">
                        <label>Contraseña</label>
                        <input type="password" name="new_password" required>
                    </div>
                    <div class="form-group">
                        <label>Rol</label>
                        <select name="new_rol">
                            <option value="2">Usuario Normal</option>
                            <option value="1">Administrador</option>
                        </select>
                    </div>
                    <button type="submit" class="btn" style="background:#16a34a;">Registrar Usuario</button>
                </form>
            </div>
        <?php endif; ?>

    <?php endif; ?>
</div>

</body>
</html>