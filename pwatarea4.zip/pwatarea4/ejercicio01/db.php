<?php
// pwatarea4
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); 
define('DB_PASS', '');     
define('DB_NAME', 'pwa_tareas');

function getDB(): PDO {
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        return $pdo;
    } catch (PDOException $e) {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";charset=utf8mb4", DB_USER, DB_PASS);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4");
        $pdo->exec("USE `" . DB_NAME . "`");
        
        // Estructura limpia de tablas
        $pdo->exec("CREATE TABLE IF NOT EXISTS roles (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(50) NOT NULL UNIQUE)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS usuarios (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, rol_id INT NOT NULL, FOREIGN KEY (rol_id) REFERENCES roles(id))");
        $pdo->exec("CREATE TABLE IF NOT EXISTS tareas (id INT AUTO_INCREMENT PRIMARY KEY, titulo VARCHAR(200) NOT NULL, descripcion TEXT, completada TINYINT(1) DEFAULT 0, prioridad ENUM('baja','media','alta') DEFAULT 'media', usuario_id INT NOT NULL, FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE)");
        
        $pdo->exec("INSERT IGNORE INTO roles (id, nombre) VALUES (1, 'admin'), (2, 'usuario')");
        $dbPassAdmin = password_hash('admin123', PASSWORD_BCRYPT);
        $dbPassUser  = password_hash('user123', PASSWORD_BCRYPT);
        
        $stmt = $pdo->prepare("INSERT IGNORE INTO usuarios (id, username, password, rol_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([1, 'admin', $dbPassAdmin, 1]);
        $stmt->execute([2, 'usuario1', $dbPassUser, 2]);
        
        return getDB();
    }
}