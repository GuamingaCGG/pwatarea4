<?php
// ejercicio01/index.php
session_start();
require_once __DIR__ . '/db.php';
$db = getDB();
$error = ''; $msg = '';

// Procesar login
if (isset($_POST['action']) && $_POST['action'] === 'login') {
    $stmt = $db->prepare("SELECT u.*, r.nombre AS rol FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE u.username = ?");
    $stmt->execute([trim($_POST['username'] ?? '')]);
    $user = $stmt->fetch();
    if ($user && password_verify($_POST['password'] ?? '', $user['password'])) {
        $_SESSION['uid'] = $user['id']; $_SESSION['username'] = $user['username']; $_SESSION['rol'] = $user['rol'];
        header("Location: index.php"); exit;
    } else { $error = "Credenciales incorrectas."; }
}

// Procesar logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy(); header("Location: index.php"); exit;
}

// Acciones con Login Activo [cite: 13]
if (!empty($_SESSION['uid'])) {
    $uid = (int)$_SESSION['uid']; $rol = $_SESSION['rol'];

    // Guardar Tarea 
    if (isset($_POST['action']) && $_POST['action'] === 'create_task') {
        $titulo = trim($_POST['titulo'] ?? '');
        $asignado = ($rol === 'admin' && !empty($_POST['usuario_id'])) ? (int)$_POST['usuario_id'] : $uid;
        if ($titulo) {
            $db->prepare("INSERT INTO tareas (titulo, descripcion, prioridad, usuario_id) VALUES (?, ?, ?, ?)")
               ->execute([$titulo, trim($_POST['descripcion'] ?? ''), $_POST['prioridad'] ?? 'media', $asignado]);
            $msg = "Tarea creada.";
        } else { $error = "El título es obligatorio."; }
    }

    // Cambiar estado (Check) 
    if (isset($_GET['action']) && $_GET['action'] === 'toggle') {
        $stmt = $db->prepare("SELECT * FROM tareas WHERE id = ?"); $stmt->execute([(int)$_GET['id']]); $t = $stmt->fetch();
        if ($t && ($rol === 'admin' || $t['usuario_id'] == $uid)) {
            $db->prepare("UPDATE tareas SET completada = ? WHERE id = ?")->execute([$t['completada'] ? 0 : 1, $t['id']]);
        }
        header("Location: index.php"); exit;
    }

    // Eliminar Tarea 
    if (isset($_GET['action']) && $_GET['action'] === 'delete_task') {
        $stmt = $db->prepare("SELECT * FROM tareas WHERE id = ?"); $stmt->execute([(int)$_GET['id']]); $t = $stmt->fetch();
        if ($t && ($rol === 'admin' || $t['usuario_id'] == $uid)) {
            $db->prepare("DELETE FROM tareas WHERE id = ?")->execute([$t['id']]); $msg = "Tarea eliminada.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"><title>Ejercicio 01 — Tareas</title>
    <style>
        body { font-family: sans-serif; background: #f4f6f9; padding: 20px; }
        .box { max-width: 600px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 12px; } .form-group label { display: block; font-weight: bold; }
        .form-group input, .form-group textarea { width:100%; padding: 8px; box-sizing: border-box; }
        .task { display: flex; justify-content: space-between; background: #f9fafb; padding: 10px; margin-bottom: 8px; border-left: 4px solid #6366f1; }
        .done { opacity: 0.5; text-decoration: line-through; }
    </style>
</head>
<body>
<div class="box">
    <h2>📋 Gestión de Tareas (Roles) </h2>
    <?php if ($error) echo "<p style='color:red;'>$error</p>"; ?>
    <?php if ($msg) echo "<p style='color:green;'>$msg</p>"; ?>

    <?php if (empty($_SESSION['uid'])): ?>
        <form action="index.php" method="POST">
            <input type="hidden" name="action" value="login">
            <div class="form-group"><label>Usuario</label><input type="text" name="username" required></div>
            <div class="form-group"><label>Contraseña</label><input type="password" name="password" required></div>
            <button type="submit">Ingresar</button>
        </form>
    <?php else: ?>
        <p>Usuario: <strong><?= $_SESSION['username'] ?></strong> (<?= $_SESSION['rol'] ?>) | <a href="index.php?action=logout">Salir</a> | <a href="../index.php">Menú Principal</a></p><hr>
        
        <form action="index.php" method="POST">
            <input type="hidden" name="action" value="create_task">
            <div class="form-group"><label>Título</label><input type="text" name="titulo" required></div>
            <div class="form-group"><label>Descripción</label><textarea name="descripcion"></textarea></div>
            <button type="submit">Agregar Tarea</button>
        </form><hr>

        <h3>Lista de Tareas</h3>
        <?php
        $stmt = ($rol === 'admin') ? $db->query("SELECT t.*, u.username FROM tareas t JOIN usuarios u ON u.id = t.usuario_id") : $db->prepare("SELECT t.*, u.username FROM tareas t JOIN usuarios u ON u.id = t.usuario_id WHERE t.usuario_id = ?");
        if ($rol !== 'admin') $stmt->execute([$uid]);
        foreach ($stmt->fetchAll() as $t):
        ?>
            <div class="task <?= $t['completada'] ? 'done' : '' ?>">
                <div><strong><?= htmlspecialchars($t['titulo']) ?></strong> <small>(Por: <?= $t['username'] ?>)</small></div>
                <div>
                    <a href="index.php?action=toggle&id=<?= $t['id'] ?>"><?= $t['completada'] ? '↩️' : '✅' ?></a>
                    <a href="index.php?action=delete_task&id=<?= $t['id'] ?>" style="color:red;">🗑️</a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
</body>
</html>