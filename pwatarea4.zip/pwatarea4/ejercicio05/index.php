<?php
// ejercicio05/index.php
$ruta_archivo = __DIR__ . '/bloc.txt';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['texto'])) {
    file_put_contents($ruta_archivo, trim($_POST['texto']));
    header("Location: index.php"); exit;
}

$texto_guardado = file_exists($ruta_archivo) ? file_get_contents($ruta_archivo) : "Escribe tus apuntes aquí...";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"><title>Ejercicio 05 — Bloc</title>
    <style>
        body { font-family: sans-serif; background: #121214; color: #e1e1e6; padding: 20px; }
        .wrapper { max-width: 600px; margin: 0 auto; background: #202024; padding: 20px; border-radius: 8px; }
        textarea { width: 100%; height: 200px; background: #121214; color: white; padding: 10px; border: 1px solid #29292e; border-radius: 4px; box-sizing: border-box; }
        .btn { background: #00875f; color: white; padding: 10px; border: none; width: 100%; margin-top: 10px; cursor: pointer; font-weight: bold; border-radius: 4px; }
    </style>
</head>
<body>
<div class="wrapper">
    <h2> Bloc de Notas (Manejo de Archivos en Servidor)</h2>
    <form action="index.php" method="POST">
        <textarea name="texto"><?= htmlspecialchars($texto_guardado) ?></textarea>
        <button type="submit" class="btn"> Guardar Cambios</button>
    </form>
    <br><a href="../index.php" style="color:#8d8d99; text-decoration:none;">← Volver al Menú</a>
</div>
</body>
</html>