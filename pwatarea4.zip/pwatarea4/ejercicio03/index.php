<?php // ejercicio03/index.php ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"><title>Ejercicio 03 — Presupuesto</title>
    <style>
        body { font-family: sans-serif; background: #0b0f19; color: #e2e8f0; padding: 20px; }
        .card { max-width: 500px; margin: 0 auto; background: #111827; padding: 25px; border-radius: 12px; border: 1px solid #1f2937; }
        .flex { display: flex; gap: 8px; margin-bottom: 15px; }
        input, button { padding: 10px; border-radius: 6px; border: 1px solid #374151; background: #1f2937; color: white; }
        button { background: #06b6d4; cursor: pointer; border: none; font-weight: bold; }
        .gasto { display: flex; justify-content: space-between; background: #1f2937; padding: 10px; margin-top: 5px; border-radius: 4px; }
    </style>
</head>
<body>
<div class="card">
    <h2> Calculadora de Gastos Dinámica </h2>
    <div class="flex">
        <input type="text" id="gasto" placeholder="Artículo o servicio">
        <input type="number" id="monto" placeholder="0.00" step="0.01">
        <button onclick="calcular()">Añadir</button>
    </div>
    <div id="lista"></div>
    <h3 style="margin-top:20px;">Total: $<span id="total">0.00</span></h3>
    <br><a href="../index.php" style="color:#9ca3af;"> Volver al Menú</a>
</div>
<script>
    let neto = 0;
    function calcular() {
        const item = document.getElementById('gasto');
        const valor = parseFloat(document.getElementById('monto').value);
        if (!item.value || isNaN(valor) || valor <= 0) return alert("Valores incorrectos.");
        
        neto += valor;
        document.getElementById('total').textContent = neto.toFixed(2);
        
        const div = document.createElement('div');
        div.className = 'gasto';
        div.innerHTML = `<span> ${item.value}</span><strong>$${valor.toFixed(2)}</strong>`;
        document.getElementById('lista').appendChild(div);
        
        item.value = ''; document.getElementById('monto').value = ''; item.focus();
    }
</script>
</body>
</html>