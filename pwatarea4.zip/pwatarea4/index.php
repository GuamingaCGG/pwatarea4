<?php
// pwatarea4/index.php — Página principal del proyecto
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tecno Guaminga — Programación Web Avanzada</title>
  <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;700;800&display=swap" rel="stylesheet" />
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --bg: #0a0a0f; --surface: #111118; --border: #1e1e2e; --accent: #7c3aed;
      --accent2: #4e06d4; --text: #e2e8f0; --muted: #64748b; --card-bg: #13131c;
    }
    body { background: var(--bg); color: var(--text); font-family: 'Syne', sans-serif; min-height: 100vh; padding: 2rem; }
    header { padding: 2rem 0; border-bottom: 1px solid var(--border); text-align: center; }
    .logo { font-size: 1.1rem; font-family: 'Space Mono', monospace; color: var(--accent2); }
    .hero { padding: 4rem 0; text-align: center; }
    .hero h1 { font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 800; background: linear-gradient(135deg, #fff, var(--accent)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .exercises { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.5rem; max-width: 1000px; margin: 0 auto; }
    .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 16px; padding: 2rem; text-decoration: none; color: var(--text); display: flex; flex-direction: column; gap: 1rem; transition: transform 0.25s, border-color 0.25s; }
    .card:hover { transform: translateY(-5px); border-color: var(--accent); }
    .card-number { font-family: 'Space Mono', monospace; font-size: 0.75rem; color: var(--accent2); }
    .card-title { font-size: 1.25rem; font-weight: 700; }
    .card-desc { font-size: 0.9rem; color: var(--muted); flex: 1; }
  </style>
</head>
<body>
  <header><span class="logo">&lt;pwatarea4 /&gt;</span></header>
  <section class="hero">
    <h1>Tarea Práctica 4</h1>
    Tecno Guaminga <p style="color: var(--muted); margin-top: 10px;">Ejercicios independientes de HTML, CSS, JS y PHP </p>
  </section>
  <main class="exercises">
    <a href="ejercicio01/index.php" class="card">
      <span class="card-number">EJERCICIO 01</span>
      <h2 class="card-title">Lista de Tareas</h2>
       <p class="card-desc">Gestión con roles (Admin/Usuario), autenticación y almacenamiento en MySQL</p>
    </a>
    <a href="ejercicio02/index.php" class="card">
      <span class="card-number">EJERCICIO 02</span>
      <h2 class="card-title">Control de Asistencia</h2>
      <p class="card-desc">Procesamiento de asistencia escolar estructurado mediante sesiones.</p>
    </a>
    <a href="ejercicio03/index.php" class="card">
      <span class="card-number">EJERCICIO 03</span>
      <h2 class="card-title">Presupuesto Dinámico</h2>
      <p class="card-desc">Uso dinámico de JavaScript para interactuar con el DOM en tiempo real.</p>
    </a>
    <a href="ejercicio04/index.php" class="card">
      <span class="card-number">EJERCICIO 04</span>
      <h2 class="card-title">Inventario CRUD</h2>
      <p class="card-desc">Inserción, lectura y eliminación de artículos utilizando PHP PDO y tablas MySQL.</p>
    </a>
    <a href="ejercicio05/index.php" class="card">
      <span class="card-number">EJERCICIO 05</span>
      <h2 class="card-title">Bloc de Notas</h2>
      <p class="card-desc">Lectura y escritura directa de archivos de texto plano (.txt) en el servidor.</p>
    </a>
  </main>
</body>
</html>